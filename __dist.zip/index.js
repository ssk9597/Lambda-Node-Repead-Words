'use strict';

// パッケージのインストール
const line = require('@line/bot-sdk');

// LINEアクセストークンの設定
const config = {
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET,
};

// インスタンス化
const client = new line.Client(config);

exports.handler = async (event, context) => {
  // eventを出力
  console.log(`【Event: 】${event}`);

  // JSONとして解析して値やオブジェクトを構築する
  const body = JSON.parse(event.body);

  // bodyを出力（JSON文字列へ戻す）
  console.log(`【body: 】${JSON.stringify(body)}`);

  // messageの配列を取得
  const messages = body.events && body.events[0];
  console.log(`【messages: 】${JSON.stringify(messages)}`);

  const post = {
    type: 'text',
    text: messages.message.text,
  };

  try {
    await client.replyMessage(messages.replyToken, post);
  } catch (err) {
    console.log(err);
  }
};
